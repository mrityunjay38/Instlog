<?php
    include'include/header.php';
    $access_token;
    if(isset($_GET['MediaId']))
    {
        $search_userId = $_GET['MediaId'];
    }
    else
    {
        header('location:index.php');
    }
    $mediaDetail = SearchMediaById($access_token , $search_userId);
//    echo"<pre>";
//    print_r($mediaDetail);
//    echo"</pre>";
    
?>
        
        <div class="main_content">
            <div class="container">
                
                <?php
                    include'include/field.php';
                    if(empty($mediaDetail['data']))
                    {
                        echo "<h3>No such User Exist</h3>";
                    }
                    else
                    {
                        ?>
                            <div class="profile_top">
                                <div class="col-md-2 profile-img">
                                    <img alt="" width="100%" src="<?php echo $mediaDetail['data']['user']['profile_picture'];?>"/>
                                </div><!---->
                                <div class="col-md-5 profile-status">
                                    <h3><?php echo $mediaDetail['data']['user']['full_name'];?></h3>
                                    <p><b>Id :-</b><?php echo $mediaDetail['data']['user']['id'];?></p>
                                    <p><b>UserName :-</b> <?php echo $mediaDetail['data']['user']['username'];?></p>
                                    <?php
                                        if(!$mediaDetail['data'] == '')
                                        {
                                           echo "<p><b>Filter :-</b>".$mediaDetail['data']['filter']."</p>";
                                        }
                                        if(!empty($mediaDetail['data']['caption']))
                                        {
                                           echo "<p><b>caption :-</b>".$mediaDetail['data']['caption']['text']."</p>";
                                        }
                                    ?>
                                </div><!--profile-status-->
                                <div class="col-md-5 profile-detail">
                                    <div class="profile-meta">
                                        <p><b><?php echo $mediaDetail['data']['comments']['count'];?></b><br/>Comment</p>
                                    </div><!---->
                                    <div class="profile-meta">
                                        <p><b><?php echo $mediaDetail['data']['likes']['count'];?></b><br/>likes</p>
                                    </div><!---->
                                </div><!--profile-status-->
                            </div><!--profile-top-->
                            <div class="profile_media">
                                <?php
                                    if($mediaDetail['data']['type'] == 'video')
                                    {
                                        ?>
                                            <video width="<?php echo $mediaDetail['data']['videos']['standard_resolution']['url']['width'];?>" height="<?php echo $mediaDetail['data']['videos']['standard_resolution']['url']['height'];?>" controls>
                                                <source src="<?php echo $mediaDetail['data']['videos']['standard_resolution']['url'];?>" type="video/mp4">
                                                <source src="movie.ogg" type="video/ogg">
                                                Your browser does not support the video tag.
                                            </video>
                                        <?php
                                    }
                                    else
                                    {

                                ?>
                                <img class="media_img_single" src="<?php echo $mediaDetail['data']['images']['standard_resolution']['url'];?>">
                                <!-- AddToAny BEGIN -->
                                <?php }?>
                                <div class="share_button">
                                    <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                                    <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    </div>
                                    <script>
                                    var a2a_config = a2a_config || {};
                                    a2a_config.linkname = "Instagram Page viewer";
                                    a2a_config.linkurl = "http://localhost/insta/single_media.php";
                                    </script>
                                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                                    <!-- AddToAny END -->
                                </div><!--share_button-->
                            </div><!--profile_media-->  
                        <?php
                    }
                ?>
                
            </div><!--container-->
        </div><!--main_content-->
<?php
    include'include/footer.php';
?>