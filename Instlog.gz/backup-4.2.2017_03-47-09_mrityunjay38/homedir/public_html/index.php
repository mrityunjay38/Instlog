<?php
    include'include/header.php';
?>

        <div class="slider_bg">
            <div class="container">
                <h2>InstLog.com - The Best Instagram Web Viewer</h2>
            </div><!--container-->
        </div><!--slider_bg-->
        <div class="search">
            <div class="container">
                <h3>Easiest way to browse Instagram profiles, photos on the web</h3>
                <?php
                    include'include/field.php';
                ?>
				<!--adsense<center class="adds_img"> <img src="images/adds.png"/></center>-->
            </div><!--container-->
        </div><!--search--->
        <div class="info_wrap">
            <div class="container">
                <h3>We Make Instagram much more easier</h3>
                <p>
                    Instagram Followers / Followings. Instagram photos and videos <br/>
                    Search Instagram @users and #hastags.
                </p>
                <h3>Why InstLog!</h3>
                <p>
                    InstLog is an Instagram web viewer. Search along instagram users and view all the posts. Check likes instagram photos or videos, share the content you liked. Use InstLog to browser through Instagram Online.

                    Search users or hashtags and find people around you...  
                </p>
                <h3>View Instagram Profile</h3>
                <p>
                    Share posts with the users on Facebook, Instagram, Twitter, Google+ and share them on all social media/email.
Discover tags just like on online Instagram or the way you use Instagram app. Type tag, hit enter and checkout posts tagged online on Instagram through InstLog.com
Search and get access to Instagram posts based on user, hashtag, and location using InstLog.com - Instagram web viewer.

View Instagram photos online using InstLog.com without any username password. No need to login on this Instagram web viewer, you simple search users, photos, tags, posts, names the way you do it on online Instagram.

Know the numbers. By using InstLog, you agree that we and our partners may set cookies to personalise content, provide social media features, analyse our traffic and advertising.
                </p>
                <h3>Popular Hashtags!</h3>
                <p>
                    # student #photographer #fashion #girl #love #music #photography #art #food #nature #artist #life #travel #cute #beauty #dog #fun #model #fitness #blogger #style #beautiful #design #designer #cat #me #funny #boy #asian #singer #makeup #dancer #happy #swag #family #pretty #musician #awesome #follow #friends #photo #cool #cats #creative #landscape #teenager #iphone #instagram #random
                </p>
            </div><!--container-->
        </div><!--info_wrap-->
        <div class="video_bg">
            <h3>View Instagram videos and photos</h3>
            <p>InstLog.com visitor's can easily view Instagram video's and photo's.</p>
        </div><!--video_bg-->
<?php
    include'include/footer.php';
?>