<?php
    include'include/helper.php';
    include'include/config.php';
	//change this 
    $path_url = "https://www.instlog.com";
	date_default_timezone_set("Asia/Kolkata");
 $url = $_SERVER['REQUEST_URI']; 
?>
<!DOCTYPE html>
<html lang="en-GB"> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Instlog.com - Instagram Web Viewer | Online Instagram</title>
        <meta name="Author" content="Instlog.com" />
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta http-equiv="x-dns-prefetch-control" content="on">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
        <meta name="keywords" content="Instagram web viewer, Online Instagram, Instagram photos online, Instagram feed, who wiew my instagram, instagram page, Instagram videos, instagram photos, instagram comments, instagram edit,instagram pages, instagram users, instagram profile, #hastags', #like4like" />
            <meta name="ROBOTS" content="INDEX, FOLLOW" />
            <meta name="description" content="Instlog.com, Instagram Web Viewer, Online Instagram photos, Instagram Profile, Instagram Video, Instagram Feed, Instagram Hastags, Instagram Feed" />
        <meta property="og:locale" content="en_GB" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Instlog.com - Instagram Web Viewer | Online Instagram | Instagram Photos" />
        <meta property="og:url" content="https://www.instlog.com<?php echo $url;?>"/>
        <meta property="og:site_name" content="Instlog"/>
        <meta property="og:image" content="" />
        <meta property="og:description" content="Instagram Web Viewer, Instagram Profile, Instagram Video, Instagram Feed, Instagram Hastags, Instagram Feed, Instagram Download and much more for enjoy Intagram. Instlog.com" />
        <link rel="canonical" href="https://instlog.com/" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!--Google Font-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <link rel="icon" type="image/png" href="<?php echo $path_url;?>/images/fav.png">
        <link rel="stylesheet" href="<?php echo $path_url;?>/css/style.css">
		<link rel="stylesheet" href="<?php echo $path_url;?>/css/responsive.css">
		
    </head>
<body itemscope itemtype="https://schema.org/WebPage">
    <div class="site_wraper">
        <header itemscope="" itemtype="">
            <div class="top_bar">
                <div class="container">
                    <a href="https://www.instlog.com"><h1><img alt="" src="/images/InstLog-Logo.png" /> <button class="btn btn-md btn-info pull-right btnTog"><i class="fa fa-bars"></i></button></h1></a>
                </div><!--container-->
            </div><!--top_bar-->
            <div class="menu" itemscope="" itemtype="">
                <div class="container">
                    <ul>
                        <li><a href="<?php echo $path_url;?>" class="HomePage">HomePage</a></li>|
<!--                        <li><a href="#">Populars</a></li>|-->
                        <li><a href="<?php echo $path_url;?>/search" class="search_menu" >search</a></li>|
                        <li><a href="/contact-us">Contact Us</a></li>
                    </ul>
                </div><!--container-->
            </div><!--menu-->
        </header>