    <div class="overflow">
                    <div class="field_wraper width90">
                        <input type="text" placeholder="Search users or tags" name="search" value="" class="form-control searchInput" required />
                    </div><!--field_wraper-->
                    <div class="field_wraper width10">
                        <button id="submit" class="btn btn-block btn-primary"><i class="fa fa-search"></i></button>
                    </div><!--field_wraper-->
</div>
