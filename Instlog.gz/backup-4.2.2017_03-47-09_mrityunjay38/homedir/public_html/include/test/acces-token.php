<?php
include'../helper.php';
$url = "https://www.instlog.com/include/test/acces-token.php";
if(isset($_GET['code']))
{
		$code = $_GET['code'];
		$uri = 'https://api.instagram.com/oauth/access_token'; 
		$data = [
			'client_id' => $client_id, 
			'client_secret' => $client_secret, 
			'grant_type' => 'authorization_code', 
			'redirect_uri' => $url, 
			'code' => $code
		];
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $uri); // uri
		curl_setopt($ch, CURLOPT_POST, true); // POST
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // POST DATA
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // RETURN RESULT true
		curl_setopt($ch, CURLOPT_HEADER, 0); // RETURN HEADER false
		curl_setopt($ch, CURLOPT_NOBODY, 0); // NO RETURN BODY false / we need the body to return
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); // VERIFY SSL HOST false
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // VERIFY SSL PEER false
		$result = json_decode(curl_exec($ch),true); // execute curl
		//echo "<pre>";
			//print_r($result['access_token']);
		//echo "</pre>";
		if(isset($result['error_type']))
		{
			echo"error";
		}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Click TO Get Access_token</h2>
  <a class="btn btn-md btn-primary" href="https://api.instagram.com/oauth/authorize/?client_id=<?php echo $client_id;?>&redirect_uri=<?php echo $url;?>&response_type=code&scope=public_content">Get Your access_token </a>
  <div class="well">
	<p>Your Access_token is : <b> 
	<?php
		if(isset($_GET['code']))
		{
		echo "<pre>";
			print_r($result['access_token']);
		echo "</pre>";
		}
	?>
	</b></p>
  </div>
</div>

</body>
</html>
