<?php
ob_start();
	$client_id = '3d9d8f86e10b48c9acc0a2dc4905a3f3';
	$client_secret = 'b0e63055870d48ec9fcad3c537e8a907';
	$access_token = '4019972137.3d9d8f8.409cb9db03674a85a5ee0e668edb4e3f';	
		function connecttoinsta($url)
		{
			 $ch = curl_init();
			 curl_setopt_array($ch , array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true, 
				CURLOPT_SSL_VERIFYPEER => false,
				CURLOPT_SSL_VERIFYHOST => 2
			 ));
			 $result = json_decode(curl_exec($ch),true);
			 curl_close($ch);
			 return($result);
		}
		//Public_search
		function public_search($access_token)
		{	
			$urls = 'https://api.instagram.com/v1/users/search?q=itzsolution&access_token='.$access_token;
			$result_search = connecttoinsta($urls);
			return($result_search);
		}
		
		//information about user
		function about_user($user_id , $access_token)
		{	
			$urls = 'https://api.instagram.com/v1/users/'.$user_id.'/?access_token='.$access_token;
			$result_search = connecttoinsta($urls);
			return($result_search);
		}
		
		//information about user media
		function about_user_media($user_id , $access_token)
		{	
			$urls = 'https://api.instagram.com/v1/users/'.$user_id.'/media/recent/?access_token='.$access_token;
			$result_search = connecttoinsta($urls);
			return($result_search);
		}
		
	
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Instaagram Api</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
<body>
	<div class="container">
		<?php
			if(isset($access_token))
			{
				
				$public_search = public_search($access_token);
				$user_id = $public_search['data'][0]['id'];
				$info_about_user = about_user($user_id ,$access_token);
				$info_about_user_media = about_user_media($user_id ,$access_token);
				
				
				?>
					<!--<div class="well">
							<h2><?php echo $result['user']['username'];?></h2>
							<img src="<?php echo $result['user']['profile_picture'];?>"/>
					</div>-->
					<div class="well col-md-12">
						<div class="col-md-2">
							<img src="<?php echo $public_search['data'][0]['profile_picture'];?>"/>
						</div>
						<div class="col-md-4">
							<p><b>Full_name</b> <?php echo $public_search['data'][0]['full_name'];?></p>
							<p><b>website</b> <?php echo $public_search['data'][0]['website'];?></p>
							<p><b>Unique Id</b> <?php echo $public_search['data'][0]['id'];?></p>
							<p><b>About YOU</b> <?php echo $public_search['data'][0]['bio'];?></p>
						</div>
						<div class="col-md-4">
							<p><b>follows</b> <?php echo $info_about_user['data']['counts']['follows'];?></p>
							<p><b>totall Medai</b> <?php echo $info_about_user['data']['counts']['media'];?></p>
							<p><b>followed_by</b> <?php echo $info_about_user['data']['counts']['followed_by'];?></p>
						</div>
					</div>
					<div class="well">
						<?php
							foreach ($info_about_user_media['data'] as $media) 
							{
								?>
								<div class="col-md-2" style="height: 366px;">
									<img width="100%" src="<?php echo $media['images']['standard_resolution']['url'];?>" />
									<p><b>caption</b> <?php echo $media['caption']['text'];?></p>
									<p><b>Likes</b> <?php echo $media['likes']['count'];?></p>
									<p><b>comments</b> <?php echo $media['comments']['count'];?></p>
								</div>
								<?php
								echo '<pre>';
									print_r($media);
								echo '</pre>';
							}
						?>						
					</div>
				<?php
				
			}
		?>
	</div><!--container-->
</body>
</html>
