        <footer>
		<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button"><span class="glyphicon glyphicon-chevron-up"></span></a>
            <div class="container">
                <div class="col-md-6 footer_info">
                    <p>Copyright 2017 Instlog.com</p><a href="<?php echo $path_url?>/privacy-policy">Privacy Policy</a><a href="<?php echo $path_url?>/terms-of-use">  Terms Of Use</a>
                </div>
                <div class="col-md-6 social">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="https://twitter.com/instlog"><i class="fa fa-twitter"></i></a>
                    <a href="https://plus.google.com/101261735786643355397"><i class="fa fa-google"></i></a>
					
                </div>
            </div><!--container-->
        </footer>
    </div><!--site_wraper-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/c803c3ba19.js"></script>
    <script src="<?php echo $path_url;?>/js/myjquery.js"></script>

</body>
</html>
<?php 
    mysqli_close($conn);
?>