<?php
    ob_start();
	//change
	$client_id = '3dc614f1e5b24c66a92b203dee24b641';
	//change
	$client_secret = 'f1ee989f4e7c472da87838a1fc890821';
	//change
	$access_token = '1397131456.3dc614f.124c6a8a7eaa4f9ea1f5da4d1ff20292';	
    
    //Curl Helper 
    function CurlHelper($url)
    {
         $ch = curl_init();
         curl_setopt_array($ch , array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true, 
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 2
         ));
         $curlResult = json_decode(curl_exec($ch),true);
         curl_close($ch);
         return($curlResult);
    }


    //Public_search User
    function PublicSearchUser($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/users/search?q='.$value.'&access_token='.$access_token;
        $result_search = CurlHelper($urls);
        return($result_search);
    }
	//crop_img
	function cropimg($value)
    {	
        $urls = 'https://api.imageresizer.io/images?url='.$value;
        $result_search = CurlHelper($urls);
        return($result_search);
    }

    
    
    //Public_search Tag
    function PublicSearchTag($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/tags/search?q='.$value.'&access_token='.$access_token;
        $result_search = CurlHelper($urls);
        return($result_search);
    }

    //Search User By Id
    function SearchUserById($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/users/'.$value.'/?access_token='.$access_token ;
        $result_search = CurlHelper($urls);
        return($result_search);
    }


    // media of user
    function SearchUserMedia($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/users/'.$value.'/media/recent/?access_token='.$access_token ;
        $result_search = CurlHelper($urls);
        return($result_search);
    }
    
    
    // media of user
    function SearchMediaByTag($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/tags/'.$value.'/media/recent?access_token='.$access_token;
        $result_search = CurlHelper($urls);
        return($result_search);
    }

    // media of user
    function SearchMediaById($access_token , $value)
    {	
        $urls = 'https://api.instagram.com/v1/media/'.$value.'?access_token='.$access_token;
        $result_search = CurlHelper($urls);
        return($result_search);
    }
?>