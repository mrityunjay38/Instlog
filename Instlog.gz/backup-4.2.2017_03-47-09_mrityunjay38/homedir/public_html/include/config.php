<?php
    $servername = "localhost";
    $username = "mrityunjay38-db";
    $password = "newtest123##";
    $dbname = "inst-data";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

?>