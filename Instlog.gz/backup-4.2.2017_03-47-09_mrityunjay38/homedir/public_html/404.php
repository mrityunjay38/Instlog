<?php
    include'include/header.php';
?>

<style type="text/css">
#center {text-align:center;margin-bottom:22%;margin-top:10%;}

h1 {
  font-size: 48px;
  font-weight: 300;
  margin: 0 0 20px 0;
}


p {
  margin: 0 0 10px;
}

</style>
<div id="center">
        <h1>File not found (404 error)</h1>
      <p class="lead">If you think what you're looking for should be here, please contact the site owner.</p>
</div>
<?php
    include'include/footer.php';
    
?>