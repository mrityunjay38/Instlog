<?php
    include'include/header.php';
    $access_token;
    if(isset($_GET['userId']))
    {
        $search_userId = $_GET['userId'];
    }
    else
    {
        header('location:index.php');
    }
    $userDetailTgId = PublicSearchUser($access_token , $search_userId);

    $userDetail = SearchUserById($access_token , $userDetailTgId['data']['0']['id']);
?>
       
        <div class="main_content">
            <div class="container">
                
                <?php
                    echo "<div style='overflow:hidden;'>";
                    include'include/field.php';
                    echo "</div>";
                    if(empty($userDetail['data']))
                    {
                        echo "<h3>No such User Exist</h3>";
                    }
                    else
                    {
                        ?>
                            <div class="profile_top">
                                <div class="col-md-2 profile-img">
                                    <img alt="" width="100%" src="<?php echo $userDetail['data']['profile_picture'];?>"/>
                                </div><!---->
                                <div class="col-md-5 profile-status">
                                    <h3><?php echo $userDetail['data']['full_name'];?></h3>
                                    <p><b>Id :-</b><?php echo $userDetail['data']['id'];?></p>
                                    
                                    <?php
                                        if(!empty($userDetail['data']['bio']))
                                        {
                                            echo '<p><b>About :-</b> ';
                                            echo $userDetail['data']['bio'];
                                            echo '</p>';
                                        }
                                    ?>
                                    <p><b>UserName :-</b> <?php echo $userDetail['data']['username'];?></p>
                                     <?php
                                        if(!empty($userDetail['data']['website']))
                                        {
                                            echo '<p><b>About :-</b> ';
                                            echo $userDetail['data']['website'];
                                            echo '</p>';
                                        }
                                    ?>
                                </div><!--profile-status-->
                                <div class="col-md-5 profile-detail">
                                    <div class="profile-meta">
                                        <p><b><?php echo $userDetail['data']['counts']['followed_by'];?></b><br/>Followed By</p>
                                    </div><!---->
                                    <div class="profile-meta">
                                        <p><b><?php echo $userDetail['data']['counts']['follows'];?></b><br/>Follows</p>
                                    </div><!---->
                                    <div class="profile-meta">
                                        <p><b><?php echo $userDetail['data']['counts']['media'];?></b><br/>Media</p>
                                    </div><!---->
                                </div><!--profile-status-->
                            </div><!--profile-top-->
						
                            <div class="profile_media">
							<div class="row">
  
                                <?php
                                    $media_user_Id = $userDetail['data']['id'];
                                    $media_user = SearchUserMedia($access_token , $media_user_Id);
								
                                    if(empty($media_user['data']))
                                    {
                                        echo "<h4>NO Media This User</h4>";
                                    }
                                    else
                                    {
										$i = 0;
                                        foreach ($media_user['data'] as $value)
                                        {
											// print_r ($value['images']);
											/*$i = $i + 1;
											if($i == '1')
											{
												echo '<div class="item"><<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2688963945386368"
     data-ad-slot="2914492137"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>';
											}
											elseif($i == '14')
											{
												echo '<div class="item"><ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2688963945386368"
     data-ad-slot="2914492137"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>';
											}
											elseif($i == '4')
											{
												echo '<div class="item"><ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2688963945386368"
     data-ad-slot="2914492137"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>';
											}*/
											
                                            ?> 
											

											<a href="<?php echo $path_url;?>/photo/<?php echo $value['id'];?>" class="item">
												<div class="well"> 
												<img width="100%" src="<?php echo $value['images']['standard_resolution']['url']?>">
												<div class="media_box">
                                                        <span><img alt="" width="30px" src="<?php echo $userDetail['data']['profile_picture'];?>"/><font><?php echo $userDetail['data']['full_name'];?></font></span>
                                                        <span><i class="fa fa-comment"></i> (<?php echo $value['comments']['count']?>)</span>
                                                        <span><i class="fa fa-heart"></i> (<?php echo $value['likes']['count'] ; ?>)</span>
                                                    </div>
												</div>
											</a>
                                            <?php
											
                                        }
                                    }
                                ?>
                                
                            </div><!--profile_media-->  
                        <?php
                    }
                ?>
				</div>
            </div><!--container-->
        </div><!--main_content-->
		
											<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<?php
    include'include/footer.php';
?>