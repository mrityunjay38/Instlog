<?php
    include'include/header.php';
    $access_token;
    if(isset($_GET['search']))
    {
      $search_value = $_GET['search'];
    }
    else
    {
        $search_value = '';
    }
$date = date("Y-m-d h:i:s");
    $UserResult = PublicSearchUser($access_token ,$search_value);
    $tagResult = PublicSearchTag($access_token , $search_value);
?>
        
        <div class="main_content">
            <div class="container">
                <div class="bread_crum">
                    <a href="#">Home</a>
                    <a class="active" href="#">Search</a>
                    <?php
                        if(!empty($search_value))
                        {
                            ?>
                                <a class="active" href="#"><?php echo $search_value ;?></a>
                            <?php
                        }
                    ?>
                </div><!--bread_crum-->
                <?php
                    include'include/field.php';
                ?>
				<!--adsense<center class="adds_img"> <img src=" images/adds.png"/></center>-->
                <div class="search_result">
                    <h4>Instagram Search Results for <?php echo $search_value; ?></h4>
                    <div class="search_tab">
                        <button class="btn btn-block btn-primary" id="searchtag">Instagram tag search results for <?php echo $search_value; ?></button>
                        <button  class="btn btn-block btn-primary" id="searchUser">Instagram user search results for <?php echo $search_value; ?></button>
                    </div><!--search_tab-->
                    <div class="search_content">
                        <?php   
                            if(empty($UserResult['data']))
                            {
                                echo "<h4>NO search result  ".$search_value."</h4>";
                            }
                            else
                            {
                                foreach ($UserResult['data'] as $value)
                                {
                                    $urlData =  $path_url."/profile/".$value['username'];
                                    $sql = "SELECT * FROM `url` WHERE `url` = '$urlData'";
                                    $result_sql = $conn->query($sql);

                                    if ($result_sql->num_rows > 0) 
                                    {
                                        // output data of each row
                                        $row = $result_sql->fetch_assoc();
                                    } 
                                    else
                                    {
                                        $sql = "INSERT INTO `Url`(`url`, `time` ,`type`) VALUES ('$urlData', '$date' , 'media')";

                                        if (mysqli_query($conn, $sql)) 
                                        {
                                            
                                        }
                                    }
                                    ?>
                                        <a href="<?php echo $path_url;?>/profile/<?php echo $value['username'];?>" class="col-md-3 user_content">
                                            <img alt="<?php echo $value['username']; ?>" src="<?php echo $value['profile_picture']; ?>" width="100%" />
                                            <p><b>Full Name :-</b><?php echo $value['full_name']; ?></p>
                                            <p><b>UserName :-</b><?php echo $value['username']; ?></p>
                                        </a><!--col-md-3-->
                                    <?php
                                }
                            }
                        ?>
                        
                    </div><!--search_content-->
                    <div class="tag_search">
                        <?php   
                            if(empty($tagResult['data']))
                            {
                                echo "<h4>NO search result  ".$search_value." Tag</h4>";
                            }
                            else
                            {
                                foreach ($tagResult['data'] as $value_tag)
                                {
                                    $urlData2 =  $path_url."/tag/".$value_tag['name'];
                                    $sql = "SELECT * FROM `url` WHERE `url` = '$urlData2'";
                                    $result_sql = $conn->query($sql);

                                    if ($result_sql->num_rows > 0) 
                                    {
                                        // output data of each row
                                        $row = $result_sql->fetch_assoc();
                                    } 
                                    else
                                    {
                                        $sql = "INSERT INTO `Url`(`url`, `time` ,`type`) VALUES ('$urlData2', '$date' , 'tag')";

                                        if (mysqli_query($conn, $sql)) 
                                        {
                                            
                                        }
                                    }
                                    ?>
                                        <a href="<?php echo $path_url;?>/tag/<?php echo $value_tag['name'] ;?>" class="tag_content col-md-4 col-sm-4">
                                            <p><b>( <?php echo $value_tag['media_count'] ;?> ) </b><?php echo $value_tag['name'] ;?></p>
                                        </a><!--tag_content-->
                                    <?php
                                }
                            }
                        ?>
                        </a><!--tag_content-->
                    </div><!--tag_content-->
                </div><!--search_result-->
            </div><!--container-->
        </div><!--main_content-->
<?php
    include'include/footer.php';
?>
