var url = 'http://instlog.com';
$(document).ready(function(){
    $(".tag_search").hide();
    $("#searchUser").addClass("active");
    $("#searchUser").click(function(){
        $(".search_content").show();
        $(".tag_search").hide();
        $("#searchUser").addClass("active");
        $("#searchtag").removeClass("active");
    });
    $("#searchtag").click(function(){
        $(".search_content").hide();
        $(".tag_search").show();
        $("#searchUser").removeClass("active");
        $("#searchtag").addClass("active");
    });
    $( "#submit" ).click(function() {
        var value = $(".searchInput").val();
        window.location.href = url+'/search/'+value;
    });
    $('.searchInput').keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
               $( "#submit" ).click();
        }
    });
});
$(document).ready(function(){
    $( "#submit" ).click(function() {
        var value = $(".searchInput").val();
        window.location.href = url+'/search/'+value;
    });
    $('.searchInput').keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
               $( "#submit" ).click();
        }
    });
	$(".btnTog").click(function() { 
	$(".menu").slideToggle();
	});
	
});

$(document).ready(function(){       
	var scroll_pos = 0;
	$(document).scroll(function() { 
		scroll_pos = $(this).scrollTop();
		if(scroll_pos > 60) {
			$(".top_bar").css('position', 'fixed');
		} else {
			$(".top_bar").css('position', 'static');
		}
	});
});
	$('#back-to-top').hide();
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});

//$( "<div class='item'><img width='100%' height='427px' src='http://www.brightspark-consulting.com/wp-content/uploads/2017/03/brightspark_sidebarads_0217.jpg.png' /></div>" ).insertAfter( $( ".item:first-child" ) );
//$( "<div class='item'> <ins class='adsbygoogle'style='display:block'data-ad-client='ca-pub-2688963945386368'data-ad-slot='8689144137'data-ad-format='auto'></ins></div>" ).insertAfter( $( ".item:nth-child(3n)" ) );
//$( "<div class='clearfix'></div>" ).insertAfter( $( ".media_image:nth-child(3n)" ) ); 