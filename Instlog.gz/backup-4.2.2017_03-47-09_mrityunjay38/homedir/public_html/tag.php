<?php
    include'include/header.php';
    $access_token;
    if(isset($_GET['media']))
    {
        $search_media = $_GET['media'];
    }
    else
    {
        header('location:index.php');
    }
    $TagDetail = SearchMediaByTag($access_token , $search_media);

?>
        
        <div class="main_content">
            <div class="container">
                
                <?php
                    include'include/field.php';
                    if(empty($TagDetail['data']))
                    {
                        echo "<h3>No Media Tag Exist</h3>";
                    }
                    else
                    {
							
                        ?>
                            <div class="profile_media">
							<div class="row">
                                <?php
                                        foreach ($TagDetail['data'] as $value)
                                        {
                                            ?>
                                            <a href="<?php echo $path_url;?>/photo/<?php echo $value['id'];?>" class="item">
												<div class="well"> 
												<img width="100%" src="<?php echo $value['images']['standard_resolution']['url']?>">
												<div class="media_box">
                                                        <span><img alt="" width="30px" src="<?php echo $value['user']['profile_picture'];?>"/><font><?php echo $value['user']['full_name'];?></font></span>
                                                        <span><i class="fa fa-comment"></i> (<?php echo $value['comments']['count']?>)</span>
                                                        <span><i class="fa fa-heart"></i> (<?php echo $value['likes']['count'] ; ?>)</span>
                                                    </div>
												</div>
											</a>
                                            <?php
                                        }
                                ?>
                                </div>
                            </div><!--profile_media-->  
                        <?php
                    }
                ?>
                
            </div><!--container-->
        </div><!--main_content-->
<?php
    include'include/footer.php';
?>