<?php
    include'include/header.php';
?>
        
        <div class="main_content">
            <div class="container">

                <div class="search_result privacy term">
				<p><b>Instlog Terms of Service</b></p>
<p>Thank you for visiting Instlog.com (the "Services", "Site"), operated by Instlog. ("Instlog" or "we" or "us", "our") is expressly conditioned on your acceptance of these Terms of Use ("Terms"). Please carefully read these Terms of Use ("Terms") so you understand how we operate this Site, what we can offer and how we can work together. Please also read our Privacy Policy. By using the Site and the Instlog Services (even if you're just visiting), you are agreeing to the Terms and Privacy Policy posted at the time of your visit.</p>

<p><b>Our customers</b></p>

<p>The Site is open to anyone 13 years of age or older, but some of the Instlog Services are only available to registered members ("Members"). You can visit the Site without registering and we will consider you a "User".</p>

<p><b>Membership responsibilities</b></p>

<p>When you become a Member, you agree to the following:</p>

<p>You have provided true information when you registered to be a Member.</p>

<p>You have given us a valid email address, and we may confirm upon registration, or at any time thereafter, via a confirming e-mail which may require a response to complete your registration or keep it active.</p>
</p>
<p>You will notify us if something changes.</p>

<p>You are 13 years of age or older.</p>

<p>You are not breaking any laws when you use the Instlog Services.</p>

<p>You will not violate these Terms as a Member.</p>

<p>You may cease use of the Instlog Services at any time. Even after you are no longer a Member, you will still be responsible for the promises you have made to us about your Content (defined below). You'll be responsible for any damages that result from your breaking those promises as further outlined below.</p>

<p><b>Cost and Pricing</b></p>

<p>Unless stated otherwise, all services are provided free of charge.</p>

<p><p>Third-party sites</b></p>

<p>Instlog use Instagram API to provide some of the services. Therefore, Instlog require that your use of the services to be in compliance with Instagram's Terms of Use at https://instagram.com/about/legal/terms/.</p>

<p>Instlog contains links to third-party sites. When you click on any link that takes you outside of Instlog, your use of the Internet will be governed by the terms of usage and privacy policies, if any, of the particular website that you are accessing.</p>

<p>Instlog will not be responsible or liable for the content, activities, offerings, privacy practices or terms of usage of other websites.</p>

<p><b>Limits on use</b></p>

<p>You agree to not use the Site and Our services to:
</p>
<p>Post unauthorized and unsolicited commercial communications.</p>

<p>Introduce e-viruses or other malicious code.</p>

<p>Policit login information or access an account belonging to someone else.</p>

<p>Bully, intimidate, or harass any user.</p>

<p>Post content that: is hate speech, threatening, or pornographic, incites violence, or contains nudity or graphic or gratuitous violence.</p>

<p>Do anything unlawful, misleading, malicious, or discriminatory.</p>

<p>Violate the privacy rights, publicity rights, copyrights, contract rights, intellectual property rights or any other rights of any person.</p>

<p>Result in a breach of contract between you and a third party.</p>

<p>Do anything that could disable, overburden, or impair the proper working or appearance of the Site and</p>

<p>Facilitate or encourage any violations of this Terms of Service.</p>

<p>You are solely responsible for complying with all applicable laws in all of your actions related to your use of the Site. You may not use the Site for activities that violate any law, statute, ordinance or regulation. You are required to comply with all applicable laws regarding online conduct.</p>

<p>You agree not to use, or to encourage or permit others to use the Services in contravention of any applicable law, statute, ordinance or regulation or in breach of Our rights or the rights of any third party.</p>

<p>It is a violation of these Terms to disrupt the Site or the way it functions, interfere with other Users' enjoyment of the Site or Instlog Services or use the Site to deceive, harass or solicit people.</p>

<p>It is also a violation to scrape the Site, fusker files or otherwise make any use of data mining, robots or similar data gathering and extraction tools.</p>

<p>It is up to Instlog whether to terminate your use for violation of these prohibitions or similar activities.</p>

<p><b>Content & Privacy</b></p>

<p>You retain all your rights to any Content you submit, upload or display on or while using Instlog. This means that you own all the Content you post or is being displayed via Instlog and are responsible for its settings:</p>

<p>You can mark your account private. Content from a private account will not show up in public search results on the Site and only Users you have given access will be able view the content.</p>

<p>Although we have created measures to protect your privacy, please be aware that just because something is marked "private," does not mean that only the people you invite will see it. Users may still be able to find the direct URL for a photo or video through other search mechanisms, and then share or link to it outside the Site.</p>

<p>Please remember, if you share Content from the Site or provide someone with a direct link to Content, others may be able to see it, even if you marked it "private" on the Site.</p>

<p>If you remove your Content from the Site or mark your account as "private" that was previously public, Instlog will promptly hide it from search results on the Site. However, we might still have it stored in backup files or on servers, and we may retain it as needed. We are not responsible for sites that it was shared to before it was marked "private."</p>

<p>Instlog has the right to place advertising, promotions, notifications or identifiers and watermarks on or near your Content, and how and what are up to us.</p>

<p>Instlog may moderate Content. However, we are not responsible for what you have uploaded and we are under no obligation to modify or remove any inappropriate Content.</p>

<p>If you stop using the Instlog Services, your Content may remain on the Site unless you actively remove your account, and the rights you granted to us and other Users remain.</p>

<p>In order to continue to improve the Site and Instlog Services, we may use software and other things on the Site that we own or that have been licensed to us ("Instlog Software"). Instlog has also created the look, feel and architecture of the Site and has posted certain images and videos ("Instlog Content"). Together the Instlog Content and Instlog Software are the "Instlog Materials." Instlog Materials are ours and remain ours. Except in viewing the Site, you agree that you will not copy, distribute, publicly perform, publicly display, reproduce or create derivative works from the Instlog Software. If you follow these Terms, you are entitled to use and display the Instlog Content the same way you would use other Public Content on the Site.</p>

<p>Other important guidelines</p>

<p>You are solely responsible for your interactions with other Members. Nonetheless, we reserve the right, but are not obligated, to intervene for the benefit of the Site and Instlog Services.</p>

<p>These Terms and the Privacy Policy can change. Again, please carefully read this document and our other policies. We may announce if any "big" changes are made, but so long as you've used the Site after the change, regardless of any separate notice, you agree to the current posted version of the Terms.</p>

<p>Our Site is hosted in the US. There may be more or fewer protections for you in your country than here.</p>

<p>Software available in connection with the Site and services offered through the Site (the "Software") is further subject to United States export controls. No Software may be downloaded from the Instlog Services or otherwise exported or re-exported in violation of U.S. export laws. Downloading or using the Software is at your sole risk.</p>

<p>These Terms are governed by, and interpreted in keeping with, the laws of the Spain, regardless of any conflict of law provisions. You and Instlog agree to submit to the exclusive jurisdiction of the courts located within Spain to resolve any dispute arising out of the Agreement or the Instlog Services. YOU AND Instlog HEREBY EACH KNOWINGLY, VOLUNTARILY AND INTENTIONALLY WAIVES ANY RIGHT IT MAY HAVE TO A TRIAL BY JURY IN RESPECT OF ANY LITIGATION (INCLUDING BUT NOT LIMITED TO ANY CLAIMS, COUNTERCLAIMS, CROSS-CLAIMS, OR THIRD PARTY CLAIMS) ARISING OUT OF, UNDER OR IN CONNECTION WITH THIS AGREEMENT. FURTHER, EACH PARTY HERETO CERTIFIES THAT NO REPRESENTATIVE OR AGENT OF EITHER PARTY HAS REPRESENTED, EXPRESSLY OR OTHERWISE, THAT SUCH PARTY WOULD NOT IN THE EVENT OF SUCH LITIGATION, SEEK TO ENFORCE THIS WAIVER OF RIGHT TO JURY TRIAL PROVISION. EACH OF THE PARTIES ACKNOWLEDGES THAT THIS SECTION IS A MATERIAL INDUCEMENT FOR THE OTHER PARTY ENTERING INTO THIS AGREEMENT.</p>

<p>As a Member of Instlog, if you become aware of misuse of the Instlog Services by any person, please contact us at http://www.Instlog.com/contact and include a URL at which the material in question may be located. If such misuse includes suspected infringement of copyright or other intellectual property.</p>

<p>You use the Site at your own risk and the Site and services are provided "AS IS."</p>

<p>We are not saying that the Site will meet any of your specific needs or that you will get any particular results if you use the Site. We are not responsible for the conduct of other Users' conduct on- or off-line.</p>

<p>We encourage you to always keep backups of your Content. Instlog is not responsible if any of your Content is deleted, or if any modification, suspension or discontinuation of the Site or services causes you to lose any Content-even if you're a Paying Member.</p>

<p>While we make an effort to keep the Site up and running at all times, we are not responsible for any errors, omissions, interruptions, deletions, defects, delays in operation or transmission, communications line failure, theft or destruction or unauthorized access to, or alteration of, any User communication, whether the result of our maintenance of the Site or any problems or technical malfunction of any network, servers, software or equipment, Internet traffic or any other failure of any nature.</p>

<p>We are not responsible for advertisements or applications or services that are posted on or through the Site, nor do we have any responsibility for the goods or services provided by our advertisers or via other websites or applications, including our print vendor.</p>

<p>Things to keep in mind
</p>
<p>Though everything in these Terms and in our Privacy Policy is a binding contract, we need to let you know the following:</p>

<p>Limitation on liability. IN NO EVENT SHALL Instlog BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL OR PUNITIVE DAMAGES, INCLUDING LOST PROFIT DAMAGES ARISING FROM YOUR USE OF THE Instlog SERVICES, EVEN IF Instlog HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. NOTWITHSTANDING ANYTHING TO THE CONTRARY CONTAINED HEREIN, Instlog's LIABILITY TO YOU FOR ANY CAUSE WHATSOEVER AND REGARDLESS OF THE FORM OF THE ACTION, WILL AT ALL TIMES BE LIMITED TO THE AMOUNT PAID, IF ANY, BY YOU TO Instlog FOR THE Instlog SERVICES DURING THE TERM OF MEMBERSHIP.</p>

<p>Your indemnity to us. If you breach any of the representations made herein regarding your rights in the Content, or your uploading of Content violates any of the promises you have made, you agree to indemnify, defend and hold Instlog, its subsidiaries, and affiliates, and their respective officers, agents, partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your use of the Site and Instlog Services in violation of that and/or arising from any Content that you post on or through the Site and Instlog Services.</p>

<p>Some obligations continue even after you've gone. Even if you close your account or we terminate your Membership, you will still be responsible for indemnifying us for breaches that took place while you used the Site and Instlog Services. Obligations you owed to us and Users of the Site, which by their nature are intended to survive closing or termination, will survive.</p>
                </div><!--search_result-->
            </div><!--container-->
        </div><!--main_content-->
<?php
    include'include/footer.php';
?>
